fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]
print("List of fruits:", fruits)
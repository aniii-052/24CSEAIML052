s = input("Enter a string: ")
rev = s[::-1]
words = s.split()
print("Reversed string:", rev)
print("List of words:", words)

p=float(input("enter principle amount:"))
t=float(input("enter time:"))
r=float(input("enter rate of interest"))
si=(p*t*r)
print("simple interst is:",si)
amount=p*(1 + r/100)**t
ci=amount-1
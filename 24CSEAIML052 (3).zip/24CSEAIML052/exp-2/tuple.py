my_tuple = (10, 20, 30, 40, 50)
print("The tuple is:", my_tuple)
print("Elements of the tuple:")
for element in my_tuple:
    print(element)

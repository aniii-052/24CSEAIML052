student = {
    "name": "Alice",
    "age": 20,
    "course": "Computer Science"
}
print("Dictionary Keys:", student.keys())
print("Dictionary Values:", student.values())
print("\nKey–Value Pairs:")
for key, value in student.items():
    print(key, ":", value)

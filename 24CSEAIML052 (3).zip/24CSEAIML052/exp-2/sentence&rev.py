sentence = input("Enter a sentence: ")
reversed_sentence = sentence[::-1]
print("Reversed Sentence:", reversed_sentence)
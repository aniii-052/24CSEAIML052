s = "   hi ram hi shyam hi mam   "
s = s.replace("hi", "hello")
s = s.strip()
print(s)

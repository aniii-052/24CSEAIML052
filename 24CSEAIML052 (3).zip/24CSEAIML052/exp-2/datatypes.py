import sys
print('size of integer:',sys.getsizeof(int()))
print('size of float:',sys.getsizeof(float()))
print('size of string:',sys.getsizeof(str()))
print('size of list:',sys.getsizeof(list()))
print('size of set:',sys.getsizeof(set()))
print('size of tuple:',sys.getsizeof(tuple()))
print('size of dictionary:',sys.getsizeof(dict()))

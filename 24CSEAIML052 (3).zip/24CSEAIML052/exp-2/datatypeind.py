i = int(input("Enter an integer: "))
s = input("Enter a string: ")
f = float(input("Enter a float value: "))
b = input("Enter a boolean value (True/False): ")
c = complex(input("Enter a complex number (e.g., 3+4j): "))
if b.lower() == "true":
    b = True
elif b.lower() == "false":
    b = False
else:
    print("Invalid boolean input! Setting default False.")
    b = False
print("Integer:", i, "\tType:", type(i))
print("String:", s, "\tType:", type(s))
print("Float:", f, "\tType:", type(f))
print("Boolean:", b, "\tType:", type(b))
print("Complex:", c, "\tType:", type(c))

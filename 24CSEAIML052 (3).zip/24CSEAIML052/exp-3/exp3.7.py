# Program to check whether two strings are equal

s1 = input("Enter first string: ")
s2 = input("Enter second string: ")

if s1 == s2:
    print("Both strings are equal")
else:
    print("Strings are not equal")

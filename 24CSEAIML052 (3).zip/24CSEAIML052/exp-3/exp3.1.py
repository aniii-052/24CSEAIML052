
s = input("Enter a string: ")

s = s.lower()

if s == s[::-1]:
    print("The string is a Palindrome")
else:
    print("The string is Not a Palindrome")

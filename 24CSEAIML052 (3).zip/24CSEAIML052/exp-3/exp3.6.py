# Program to check vowel or consonant

ch = input("Enter an alphabet: ").lower()

if ch in ('a', 'e', 'i', 'o', 'u'):
    print("It is a Vowel")
elif ch.isalpha() and len(ch) == 1:
    print("It is a Consonant")
else:
    print("Invalid input! Please enter a single alphabet.")

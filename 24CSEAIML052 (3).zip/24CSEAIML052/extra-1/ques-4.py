text=input("enter a string:")
reversed_text=text[::-1]
vowels=0
consonant=0
vowel_set="aeiouAEIOU"
for char in text:
    if char.isalpha():
        if char in vowel_set:
            vowels+=1
        else:
            consonant+=1
print("reversed string:",reversed_text)
print("no. of vowels:",vowels)
print("no. of consonant:",consonant)
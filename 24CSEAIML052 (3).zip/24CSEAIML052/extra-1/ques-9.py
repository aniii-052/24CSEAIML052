'''x=int(input("enter a no:"))
print(x)
print("binary equivalent is:",bin(x))
print("octal equivalent is:",oct(x))
print("hexa decimal equivalent is:",hex(x))'''

'''a=[10,20,30,20,40,20]
element=20
count=a.count(element)
print(count)'''

'''a=int(input("enter a no:"))
b=int(input("enter another no:"))
print(a)if a>b else print(b)'''

'''i=1
n=int(input("enter a no:"))
while (i<=10):
    print(n*i)
    i+=1'''

'''name='anisha'
for ch in name:
    print(ch)'''

'''name='anisha'
for i in range(len(name)):
    print(i,":",name[i])'''

'''for x in range(25,0,-2):
    print(x)'''

'''l1=[1,2,3]
l2=['a','b','c']
for i in zip(l1,l2):
    print(i)'''

for x in range(1,100,3):
    pass
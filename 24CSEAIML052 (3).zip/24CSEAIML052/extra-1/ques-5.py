def meters_to_kilometers(meters):
    return meters/1000
meters=float(input("enter meters:"))
kilometers=meters_to_kilometers(meters)
print("kilometer will be:",kilometers)
n=int(input("enter a no:"))
temp=n
rev=0
while n>0:
    rev=rev*10+n%10
    n=n//10
if temp==rev:
    print("it's a palindrome no")
else:
    print("it's not a palindrome no")
num = input("Enter a 5-digit number: ")
if len(num) == 5 and num.isdigit():
    print("Digits at odd locations:")
    for i in range(0, 5, 2):
        print(num[i])
else:
    print("Please enter exactly a 5-digit number")

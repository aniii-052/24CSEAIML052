l=[1,2,3,4,5]
l=list(map(lambda n:n*n,l))
print(l)
def greet(name="Anisha"):
    print("hello ",name)
greet()

def add(a, b):
    return a + b
result = add(5, 10)
print("add:", result)

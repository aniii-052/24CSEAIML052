def display(name,age):
    print(name,age)
display(age=19,name="Anisha")
def total(*nums):
    print("sum:",sum(nums))
total(10,20,30)
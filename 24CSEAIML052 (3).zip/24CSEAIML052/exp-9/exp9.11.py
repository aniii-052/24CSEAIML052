s=lambda n:n*n
print("square is :",s(4))
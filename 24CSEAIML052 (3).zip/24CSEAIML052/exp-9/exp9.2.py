def product (a,b):
    print("product:",a*b)
product(4,6)
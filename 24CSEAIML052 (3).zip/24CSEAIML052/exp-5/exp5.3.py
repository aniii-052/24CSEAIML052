celsius = [0, 10, 20, 30, 40]


for c in celsius:
    f = (c * 9/5) + 32
    print(c,"c=",f,"F")

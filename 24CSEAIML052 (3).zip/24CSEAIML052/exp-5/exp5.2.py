
my_list = [10, 20, 30, 40]
print("Looping over list:")
for item in my_list:
    print(item)
print()

my_tuple = (1, 2, 3, 4)
print("Looping over tuple:")
for item in my_tuple:
    print(item)
print()

my_dict = {'a': 100, 'b': 200, 'c': 300}
print("Looping over dictionary keys:")
for key in my_dict:
    print(key, "->", my_dict[key])
print()

my_set = {5, 10, 15, 20}
print("Looping over set:")
for item in my_set:
    print(item)

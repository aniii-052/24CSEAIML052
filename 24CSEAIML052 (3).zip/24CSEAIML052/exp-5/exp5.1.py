# Generate Fibonacci series up to 1000
fib = [0, 1]

while True:
    next_term = fib[-1] + fib[-2]
    if next_term > 1000:
        break
    fib.append(next_term)

# Find sum of even-valued terms
even_sum = 0
for num in fib:
    if num % 2 == 0:
        even_sum += num

# Output
print("Fibonacci series up to 1000:")
print(fib)
print("Sum of even-valued terms:", even_sum)

a=10
b=20
print("before swapping:",a,b)
a=a+b
b=a-b
a=a-b
print("after swapping:",a,b)
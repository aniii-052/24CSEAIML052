m1=float(input("enter marks:"))
m2=float(input("enter marks"))
m3=float(input("enter marks"))
sum=m1+m2+m3
percentage=(sum/300)*100
print("total marks:",sum)
print("percentage:",percentage)

Name="Anisha"
age=19
address="gunupur"
print("Name:",Name)
print("age:",age)
print("address:",address)
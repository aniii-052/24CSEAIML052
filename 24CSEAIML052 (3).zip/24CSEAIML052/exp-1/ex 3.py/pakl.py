string = input("enter a string")
string_lower = string.lower()
if string_lower == string_lower[-1] :
    print("The string is a palindrome")
else :
    print("The string is not a palindrome")

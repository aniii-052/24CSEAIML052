day = int(input("Enter a digit (0 to 6):"))

if day==0:
    print("Sunday")
elif day==1:
    print("Monday")
elif day==2:
    print("Tuesday")
elif day==3:
    print("Wednesday")
elif day==4:
    print("Thrusday")
elif day==5:
    print("Friday")
elif day==6:
    print("Saturday")

print("Invalid input! please enter a number between 0 and 6: ")

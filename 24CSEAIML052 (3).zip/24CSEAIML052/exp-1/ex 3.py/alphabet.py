ch = input("Enter an alphabet: ")

if ch in "aeiouAEIOU":
    print("It is a vowel: ")
else:
    print("It is a consonant: ")
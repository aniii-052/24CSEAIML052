a=10
b=20
print("before swapping:",a,b)
c=a
a=b
b=c
print("after swapping:",a,b)
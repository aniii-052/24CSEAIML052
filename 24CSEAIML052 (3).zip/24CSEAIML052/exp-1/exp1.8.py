a=float(input("enter l:"))
b=float(input("enter b:"))
c=float(input("enter h                                                                             :"))
s=(a+b+c)/2
area=(s*(s-a)*(s-b)*(s-c))**0.5
perimeter=a+b+c
print("\nPerimeterP:",perimeter)
print("area:",area)                                            
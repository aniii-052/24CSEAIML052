a=18
b=19
sum=a+b
product=a*b
print("sum:",sum)
print("product:",product)

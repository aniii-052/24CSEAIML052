radius=10
pi=3.14159
area=pi*radius*radius
perimeter=2*pi*radius
print("radius:",radius)
print("area:",area)
print("perimeter:",perimeter)


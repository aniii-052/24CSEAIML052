print("Decimal equivalents of 1/n:")

for n in range(2, 101):
    print("1/{0} = {1}".format(n, 1/n))





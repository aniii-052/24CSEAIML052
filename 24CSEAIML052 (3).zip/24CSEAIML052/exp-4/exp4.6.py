num = int(input("Enter a number: "))
fact = 1

if num < 0:
    print("Factorial does not exist for negative numbers")
else:
    while num > 0:
        fact = fact * num
        num -= 1
    print("Factorial =", fact)

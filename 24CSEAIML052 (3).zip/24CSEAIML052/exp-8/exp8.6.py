def reverse_string(s):
    print(s[::-1])

reverse_string("hello")

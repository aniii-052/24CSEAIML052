def check_even_odd(n):
    if n % 2 == 0:
        print("Even")
    else:
        print("Odd")

check_even_odd(7)

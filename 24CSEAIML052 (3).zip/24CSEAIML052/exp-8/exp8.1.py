def square(n):
    return n * n

num = 5
result = square(num)
print("Square of", num, "is", result)

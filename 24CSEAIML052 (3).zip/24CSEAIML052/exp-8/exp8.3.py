def sum_two(a, b):
    print(a + b)

sum_two(3, 5)

paragraph = "madam level python teaches level madam"

words = paragraph.split()

count = 0
for w in words:
    count = count + 1

palindrome_count = 0
for w in words:
    if w == w[::-1]:
        palindrome_count = palindrome_count + 1

print("Reversed words:")
for w in words:
    print(w[::-1])

print("\nTotal words:", count)
print("Number of palindrome words:", palindrome_count)

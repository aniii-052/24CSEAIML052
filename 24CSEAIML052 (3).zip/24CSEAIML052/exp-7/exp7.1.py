m = int(input("Enter m: "))
n = int(input("Enter n: "))

lst = []
for i in range(m, n+1):
    lst.append(i)

print("List:", lst)

s = sum(lst)
print("Sum:", s)
print("Average:", s/len(lst))
print("Largest:", max(lst))
print("Smallest:", min(lst))

lst2 = []
for x in lst:
    if x % 3 != 0:
        lst2.append(x)

print("Without divisible by 3:", lst2)
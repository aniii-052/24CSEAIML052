def count_vowels(s):
    count=0
    for ch in s:
        if ch in 'aeiouAEIOU':
            count+=1
    return count
text=input("enter a string:")
print("no. of vowels :",count_vowels(text))
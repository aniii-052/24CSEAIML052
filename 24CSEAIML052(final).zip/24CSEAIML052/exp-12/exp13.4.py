import matplotlib.pyplot as plt
sizes =[15, 30, 45, 101]
labels= ['A', 'B', 'C', 'D']
colors = ['gold', 'yellowgreen', 'lightcoral', 'lightskyblue']
explode=(0, 0.1, 0, 0) # Explode 2nd slice.
plt.pic(sizes, explode=explode, labels=labels, colors=colors, autoput=% 1.1%%',
shadow-True, startangle=140)
plt.title("Pie Chart")
plt.axis('equal')
plt.show()
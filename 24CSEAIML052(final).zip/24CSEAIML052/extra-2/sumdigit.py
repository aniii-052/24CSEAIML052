def sum_digits(n):
    if n==0:
        return 0
    else:
        return n%10 +sum_digits(n//10)
num=int(input("enter no:"))
print("sum of digits:",sum_digits(num))
a = float(input("Enter a: "))
b = float(input("Enter b: "))
c = float(input("Enter c: "))

d = b*b - 4*a*c

if d>0:
    r1 = (-b + d**0.5) / 2*a
    r2 = (-b - d**0.5) / 2*a

    print("Two real roots:",r1,"and",r2)

elif d==0:
     r=-b/2*a
     print("One real root: ",r)
else:
     print("No real roots: ")
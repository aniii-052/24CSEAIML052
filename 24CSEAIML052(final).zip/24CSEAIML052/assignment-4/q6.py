#wap to calculate factorial of a no using recursion
def factorial(n):
    if n==0:
        result=1
    else:
        result=n*factorial(n-1)
    return result
n=int(input("enter the no:"))
if(n<0):
    print("it is a negative no")
else:
    print("factorial of",n,"is",factorial(n))
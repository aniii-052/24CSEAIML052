#wap to create a function that prints the 1st 15 terms of the fibonacci series without using recurssion
def fibonacci(n):
    a=1
    b=1
    print(a,b,end=" ")
    for i in range(2,n):
        c=a+b
        print(c,end=" ")
        a=b
        b=c
n=int(input("enter the no of terms you want to print:"))
print("the fibonacci series of 1st",n,"terms are:")
fibonacci(n)
class Father:
    def skill1(self):
        print("Father's skill: Gardening")
class Mother:
    def skill2(self):
        print("Mother's skill: Cooking")
class Child(Father, Mother):
    def skill3(self):
        print("Child's skill: Programming")
obj = Child()
obj.skill1()  
obj.skill2()  
obj.skill3()   
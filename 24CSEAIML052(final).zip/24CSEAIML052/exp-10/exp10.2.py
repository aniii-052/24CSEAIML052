class GrandParent:
    def property(self):
        print("Grandparent's property: 10 Acres of Land")
class Parent(GrandParent):
    def business(self):
        print("Parent's business: Grocery Shop")
class Child(Parent):
    def education(self):
        print("Child's education: Engineering Degree")
obj = Child()
obj.property()     
obj.business()    
obj.education()  
class Parent:
    def show(self):
        print("this is parent class")
class child(Parent):
    def show(self):
        print("this is child class")
obj1=Parent()
obj1.show()
obj2=child()
obj2.show()
Parent_ref=child()
Parent_ref.show()